var funcao_8c =
[
    [ "apresentarLista", "funcao_8c.html#af957e4140e89bdf54056d6d381c35b82", null ],
    [ "apresentarListaNef", "funcao_8c.html#a909731b047c9da8b3fd53e08b9fdefe9", null ],
    [ "apresentarMatriz", "funcao_8c.html#ac31478cd4b125ff169d04263a3ba9573", null ],
    [ "atualizarMatriz", "funcao_8c.html#a45d5ccc3ee9341474afc44e73475d76f", null ],
    [ "igualarMatrizes", "funcao_8c.html#a79802d5e95d26d76bca730e07ce288e8", null ],
    [ "inserirAntena", "funcao_8c.html#a0caf0b54deb90e026d66c8ee5d718c6a", null ],
    [ "inserirNefasto", "funcao_8c.html#a60d611b34c7be07e4e578482ac3749ef", null ],
    [ "LerLista", "funcao_8c.html#a0dd3787db1a292cee40267e850469704", null ],
    [ "matrizNefastos", "funcao_8c.html#a7c100c209dce8c29abd13961c75f2fcb", null ],
    [ "removerAntena", "funcao_8c.html#a5e363afa7bf8a0d74560ec1e766a52f6", null ]
];