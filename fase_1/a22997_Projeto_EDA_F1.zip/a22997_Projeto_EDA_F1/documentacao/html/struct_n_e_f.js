var struct_n_e_f =
[
    [ "proxNef", "struct_n_e_f.html#a613466b4b7c4b43e7bc9e48a65fcd995", null ],
    [ "x", "struct_n_e_f.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "struct_n_e_f.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];