var indexSectionsWithContent =
{
  0: "afilmnprxy",
  1: "an",
  2: "fm",
  3: "ailmr",
  4: "fpxy",
  5: "an",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

