var searchData=
[
  ['proxantena_0',['proxAntena',['../struct_a_n_t.html#aa5fc87ffe6a13c79d8daba3b55b34c0e',1,'ANT']]],
  ['proxnef_1',['proxNef',['../struct_n_e_f.html#a613466b4b7c4b43e7bc9e48a65fcd995',1,'NEF']]]
];
