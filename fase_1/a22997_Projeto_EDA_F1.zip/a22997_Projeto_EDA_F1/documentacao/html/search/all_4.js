var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['matriznefastos_2',['matrizNefastos',['../projetoeda_2funcao_8h.html#a7c100c209dce8c29abd13961c75f2fcb',1,'matrizNefastos(char matriz[MAX_LINHAS][MAX_COLUNAS], int linhas, int colunas):&#160;funcao.c'],['../funcao_8c.html#a7c100c209dce8c29abd13961c75f2fcb',1,'matrizNefastos(char matriz[MAX_LINHAS][MAX_COLUNAS], int linhas, int colunas):&#160;funcao.c'],['../projetoedalib_2funcao_8h.html#a7c100c209dce8c29abd13961c75f2fcb',1,'matrizNefastos(char matriz[MAX_LINHAS][MAX_COLUNAS], int linhas, int colunas):&#160;funcao.c']]],
  ['max_5fcolunas_3',['MAX_COLUNAS',['../projetoeda_2funcao_8h.html#ad624bf76d9366faecf9041ef6ffffcb9',1,'MAX_COLUNAS:&#160;funcao.h'],['../projetoedalib_2funcao_8h.html#ad624bf76d9366faecf9041ef6ffffcb9',1,'MAX_COLUNAS:&#160;funcao.h']]],
  ['max_5flinhas_4',['MAX_LINHAS',['../projetoeda_2funcao_8h.html#ab44f6d43935e7b204b295865fc8c1edc',1,'MAX_LINHAS:&#160;funcao.h'],['../projetoedalib_2funcao_8h.html#ab44f6d43935e7b204b295865fc8c1edc',1,'MAX_LINHAS:&#160;funcao.h']]]
];
