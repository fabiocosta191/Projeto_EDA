var searchData=
[
  ['nef_0',['NEF',['../struct_n_e_f.html',1,'']]]
];
