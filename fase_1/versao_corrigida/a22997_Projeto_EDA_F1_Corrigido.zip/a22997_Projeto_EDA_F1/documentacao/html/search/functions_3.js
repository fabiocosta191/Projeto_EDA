var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['matriznefastos_1',['matrizNefastos',['../projetoeda_2funcao_8h.html#a7c100c209dce8c29abd13961c75f2fcb',1,'matrizNefastos(char matriz[MAX_LINHAS][MAX_COLUNAS], int linhas, int colunas):&#160;funcao.c'],['../funcao_8c.html#a7c100c209dce8c29abd13961c75f2fcb',1,'matrizNefastos(char matriz[MAX_LINHAS][MAX_COLUNAS], int linhas, int colunas):&#160;funcao.c'],['../projetoedalib_2funcao_8h.html#a7c100c209dce8c29abd13961c75f2fcb',1,'matrizNefastos(char matriz[MAX_LINHAS][MAX_COLUNAS], int linhas, int colunas):&#160;funcao.c']]]
];
