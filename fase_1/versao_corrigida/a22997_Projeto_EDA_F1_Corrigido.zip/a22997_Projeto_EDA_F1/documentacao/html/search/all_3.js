var searchData=
[
  ['lerlista_0',['LerLista',['../projetoeda_2funcao_8h.html#a0dd3787db1a292cee40267e850469704',1,'LerLista(const char *nomeFicheiro, char matriz[MAX_LINHAS][MAX_COLUNAS], int *linhas, int *colunas):&#160;funcao.c'],['../funcao_8c.html#a0dd3787db1a292cee40267e850469704',1,'LerLista(const char *nomeFicheiro, char matriz[MAX_LINHAS][MAX_COLUNAS], int *linhas, int *colunas):&#160;funcao.c'],['../projetoedalib_2funcao_8h.html#a0dd3787db1a292cee40267e850469704',1,'LerLista(const char *nomeFicheiro, char matriz[MAX_LINHAS][MAX_COLUNAS], int *linhas, int *colunas):&#160;funcao.c']]]
];
