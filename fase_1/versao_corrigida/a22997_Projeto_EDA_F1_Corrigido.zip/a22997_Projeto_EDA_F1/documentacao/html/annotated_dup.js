var annotated_dup =
[
    [ "ANT", "struct_a_n_t.html", "struct_a_n_t" ],
    [ "NEF", "struct_n_e_f.html", "struct_n_e_f" ]
];