var projetoeda_2funcao_8h =
[
    [ "Ant", "struct_ant.html", "struct_ant" ],
    [ "Nef", "struct_nef.html", "struct_nef" ],
    [ "AntNef", "struct_ant_nef.html", "struct_ant_nef" ],
    [ "MAX_COLUNAS", "projetoeda_2funcao_8h.html#ad624bf76d9366faecf9041ef6ffffcb9", null ],
    [ "MAX_LINHAS", "projetoeda_2funcao_8h.html#ab44f6d43935e7b204b295865fc8c1edc", null ],
    [ "AdicionarAntena", "group___antenas.html#gaf957d6a53e29b4504367f27beb858bb9", null ],
    [ "ApresentarLista", "group___antenas.html#ga908a4cd69d0e74ecd0500fc85e4c90cc", null ],
    [ "ApresentarListaNef", "group___nefastos.html#gaa28d290058a7ad68746554223e82fbe1", null ],
    [ "ApresentarMatrizLista", "group___antenas.html#ga5ef24be2defa86d485ed72d0c495088e", null ],
    [ "ApresentarMatrizListaNef", "group___nefastos.html#ga16798ac8d9c91ea8d5e7911305d8c671", null ],
    [ "EncontrarNefastos", "group___nefastos.html#ga2e4798a06d5d3c5469e10537a1a17121", null ],
    [ "FreeAntNef", "group___memoria.html#gabe9a9c0979bb1220204c956f2b50127f", null ],
    [ "FreeLista", "group___memoria.html#ga855309e2366d9e593b7cbfeec6ccafaf", null ],
    [ "FreeListaNef", "group___memoria.html#ga130620bba45fe2a728f1800b9780e9d4", null ],
    [ "InserirAntena", "group___antenas.html#ga5634cbe9bfd58f5b46a9f64e7603b776", null ],
    [ "InserirNefasto", "group___nefastos.html#gabcb2df429138321bf1a982da105b7eba", null ],
    [ "LerLista", "group___antenas.html#gab005b833253ce78f9ddff1cd4b801093", null ],
    [ "RemoverAntena", "group___antenas.html#ga9acc7b3fcccbb825057aa9a70cfc122a", null ]
];