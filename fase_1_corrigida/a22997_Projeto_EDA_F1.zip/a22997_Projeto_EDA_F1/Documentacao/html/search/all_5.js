var searchData=
[
  ['id_0',['id',['../struct_ant.html#a7441ef0865bcb3db9b8064dd7375c1ea',1,'Ant']]],
  ['inserirantena_1',['InserirAntena',['../group___antenas.html#ga5634cbe9bfd58f5b46a9f64e7603b776',1,'InserirAntena(Ant *lista, char freq, int x, int y, int id):&#160;funcao.c'],['../group___antenas.html#ga5634cbe9bfd58f5b46a9f64e7603b776',1,'InserirAntena(Ant *lista, char freq, int x, int y, int id):&#160;funcao.c']]],
  ['inserirnefasto_2',['InserirNefasto',['../group___nefastos.html#gabcb2df429138321bf1a982da105b7eba',1,'InserirNefasto(Nef *listaNef, int x, int y, int ant1, int ant2, Ant *lista):&#160;funcao.c'],['../group___nefastos.html#gabcb2df429138321bf1a982da105b7eba',1,'InserirNefasto(Nef *listaNef, int x, int y, int ant1, int ant2, Ant *lista):&#160;funcao.c']]]
];
