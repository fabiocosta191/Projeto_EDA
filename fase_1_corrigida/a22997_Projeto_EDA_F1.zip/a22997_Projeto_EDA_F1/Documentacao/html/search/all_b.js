var searchData=
[
  ['x_0',['x',['../struct_ant.html#a6150e0515f7202e2fb518f7206ed97dc',1,'Ant::x'],['../struct_nef.html#a6150e0515f7202e2fb518f7206ed97dc',1,'Nef::x']]]
];
