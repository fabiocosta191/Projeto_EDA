var searchData=
[
  ['lerlista_0',['LerLista',['../group___antenas.html#gab005b833253ce78f9ddff1cd4b801093',1,'LerLista(const char *nomeFicheiro, const char *tipoFicheiro, int *linhas, int *colunas):&#160;funcao.c'],['../group___antenas.html#gab005b833253ce78f9ddff1cd4b801093',1,'LerLista(const char *nomeFicheiro, const char *tipoFicheiro, int *linhas, int *colunas):&#160;funcao.c']]],
  ['lista_1',['lista',['../struct_ant_nef.html#acc6bf784e10d704a24d429dce10c66fd',1,'AntNef']]],
  ['listanef_2',['listaNef',['../struct_ant_nef.html#a80c508e64ee6ab650bce0c1fceee5587',1,'AntNef']]]
];
