var searchData=
[
  ['de_20antenas_0',['Fun��es de Manipula��o de Antenas',['../group___antenas.html',1,'']]],
  ['de_20gest�o_20de_20mem�ria_1',['Fun��es de Gest�o de Mem�ria',['../group___memoria.html',1,'']]],
  ['de_20manipula��o_20de_20antenas_2',['Fun��es de Manipula��o de Antenas',['../group___antenas.html',1,'']]],
  ['de_20manipula��o_20de_20nefastos_3',['Fun��es de Manipula��o de Nefastos',['../group___nefastos.html',1,'']]],
  ['de_20mem�ria_4',['Fun��es de Gest�o de Mem�ria',['../group___memoria.html',1,'']]],
  ['de_20nefastos_5',['Fun��es de Manipula��o de Nefastos',['../group___nefastos.html',1,'']]]
];
