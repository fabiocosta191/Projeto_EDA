var indexSectionsWithContent =
{
  0: "adefgilmnprxy",
  1: "an",
  2: "fm",
  3: "aefilmr",
  4: "afilpxy",
  5: "m",
  6: "adfgmn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Modules"
};

