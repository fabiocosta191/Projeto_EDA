var searchData=
[
  ['y_0',['y',['../struct_ant.html#a0a2f84ed7838f07779ae24c5a9086d33',1,'Ant::y'],['../struct_nef.html#a0a2f84ed7838f07779ae24c5a9086d33',1,'Nef::y']]]
];
