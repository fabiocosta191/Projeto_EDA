var searchData=
[
  ['removerantena_0',['RemoverAntena',['../group___antenas.html#ga9acc7b3fcccbb825057aa9a70cfc122a',1,'RemoverAntena(AntNef *listaAntNef, int x, int y):&#160;funcao.c'],['../group___antenas.html#ga9acc7b3fcccbb825057aa9a70cfc122a',1,'RemoverAntena(AntNef *listaAntNef, int x, int y):&#160;funcao.c']]]
];
