var searchData=
[
  ['encontrarnefastos_0',['EncontrarNefastos',['../group___nefastos.html#ga2e4798a06d5d3c5469e10537a1a17121',1,'EncontrarNefastos(Ant *lista, int linhas, int colunas):&#160;funcao.c'],['../group___nefastos.html#ga2e4798a06d5d3c5469e10537a1a17121',1,'EncontrarNefastos(Ant *lista, int linhas, int colunas):&#160;funcao.c']]]
];
