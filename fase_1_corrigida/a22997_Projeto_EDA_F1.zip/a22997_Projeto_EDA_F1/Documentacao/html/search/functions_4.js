var searchData=
[
  ['lerlista_0',['LerLista',['../group___antenas.html#gab005b833253ce78f9ddff1cd4b801093',1,'LerLista(const char *nomeFicheiro, const char *tipoFicheiro, int *linhas, int *colunas):&#160;funcao.c'],['../group___antenas.html#gab005b833253ce78f9ddff1cd4b801093',1,'LerLista(const char *nomeFicheiro, const char *tipoFicheiro, int *linhas, int *colunas):&#160;funcao.c']]]
];
