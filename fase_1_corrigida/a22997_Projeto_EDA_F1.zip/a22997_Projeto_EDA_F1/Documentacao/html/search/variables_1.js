var searchData=
[
  ['freqantena_0',['freqAntena',['../struct_ant.html#a3419940d73191a069f0f2cb626622b92',1,'Ant']]]
];
