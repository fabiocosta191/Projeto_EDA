var searchData=
[
  ['freeantnef_0',['FreeAntNef',['../group___memoria.html#gabe9a9c0979bb1220204c956f2b50127f',1,'FreeAntNef(AntNef *listaAntNef):&#160;funcao.c'],['../group___memoria.html#gabe9a9c0979bb1220204c956f2b50127f',1,'FreeAntNef(AntNef *listaAntNef):&#160;funcao.c']]],
  ['freelista_1',['FreeLista',['../group___memoria.html#ga855309e2366d9e593b7cbfeec6ccafaf',1,'FreeLista(Ant *lista):&#160;funcao.c'],['../group___memoria.html#ga855309e2366d9e593b7cbfeec6ccafaf',1,'FreeLista(Ant *lista):&#160;funcao.c']]],
  ['freelistanef_2',['FreeListaNef',['../group___memoria.html#ga130620bba45fe2a728f1800b9780e9d4',1,'FreeListaNef(Nef *listaNef):&#160;funcao.c'],['../group___memoria.html#ga130620bba45fe2a728f1800b9780e9d4',1,'FreeListaNef(Nef *listaNef):&#160;funcao.c']]],
  ['freqantena_3',['freqAntena',['../struct_ant.html#a3419940d73191a069f0f2cb626622b92',1,'Ant']]],
  ['fun��es_20de_20gest�o_20de_20mem�ria_4',['Fun��es de Gest�o de Mem�ria',['../group___memoria.html',1,'']]],
  ['fun��es_20de_20manipula��o_20de_20antenas_5',['Fun��es de Manipula��o de Antenas',['../group___antenas.html',1,'']]],
  ['fun��es_20de_20manipula��o_20de_20nefastos_6',['Fun��es de Manipula��o de Nefastos',['../group___nefastos.html',1,'']]],
  ['funcao_2ec_7',['funcao.c',['../funcao_8c.html',1,'']]],
  ['funcao_2eh_8',['funcao.h',['../projetoeda_2funcao_8h.html',1,'(Global Namespace)'],['../projetoedalib_2funcao_8h.html',1,'(Global Namespace)']]]
];
