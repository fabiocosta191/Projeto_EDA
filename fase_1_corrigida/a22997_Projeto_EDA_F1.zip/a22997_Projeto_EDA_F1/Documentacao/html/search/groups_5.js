var searchData=
[
  ['nefastos_0',['Fun��es de Manipula��o de Nefastos',['../group___nefastos.html',1,'']]]
];
