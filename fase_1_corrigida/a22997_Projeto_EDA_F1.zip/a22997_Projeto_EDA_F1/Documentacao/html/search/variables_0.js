var searchData=
[
  ['antena1_0',['antena1',['../struct_nef.html#a6fd3fc1721340aa6cda6ff64130ee22d',1,'Nef']]],
  ['antena2_1',['antena2',['../struct_nef.html#a8480896859f1fd5c82e65d9409a60251',1,'Nef']]]
];
