var searchData=
[
  ['adicionarantena_0',['AdicionarAntena',['../group___antenas.html#gaf957d6a53e29b4504367f27beb858bb9',1,'AdicionarAntena(AntNef *listaAntNef, char freq, int x, int y, int linhas, int colunas):&#160;funcao.c'],['../group___antenas.html#gaf957d6a53e29b4504367f27beb858bb9',1,'AdicionarAntena(AntNef *listaAntNef, char freq, int x, int y, int linhas, int colunas):&#160;funcao.c']]],
  ['ant_1',['Ant',['../struct_ant.html',1,'']]],
  ['antena1_2',['antena1',['../struct_nef.html#a6fd3fc1721340aa6cda6ff64130ee22d',1,'Nef']]],
  ['antena2_3',['antena2',['../struct_nef.html#a8480896859f1fd5c82e65d9409a60251',1,'Nef']]],
  ['antenas_4',['Fun��es de Manipula��o de Antenas',['../group___antenas.html',1,'']]],
  ['antnef_5',['AntNef',['../struct_ant_nef.html',1,'']]],
  ['apresentarlista_6',['ApresentarLista',['../group___antenas.html#ga908a4cd69d0e74ecd0500fc85e4c90cc',1,'ApresentarLista(Ant *lista):&#160;funcao.c'],['../group___antenas.html#ga908a4cd69d0e74ecd0500fc85e4c90cc',1,'ApresentarLista(Ant *lista):&#160;funcao.c']]],
  ['apresentarlistanef_7',['ApresentarListaNef',['../group___nefastos.html#gaa28d290058a7ad68746554223e82fbe1',1,'ApresentarListaNef(Nef *listaNef):&#160;funcao.c'],['../group___nefastos.html#gaa28d290058a7ad68746554223e82fbe1',1,'ApresentarListaNef(Nef *listaNef):&#160;funcao.c']]],
  ['apresentarmatrizlista_8',['ApresentarMatrizLista',['../group___antenas.html#ga5ef24be2defa86d485ed72d0c495088e',1,'ApresentarMatrizLista(Ant *lista, int linhas, int colunas):&#160;funcao.c'],['../group___antenas.html#ga5ef24be2defa86d485ed72d0c495088e',1,'ApresentarMatrizLista(Ant *lista, int linhas, int colunas):&#160;funcao.c']]],
  ['apresentarmatrizlistanef_9',['ApresentarMatrizListaNef',['../group___nefastos.html#ga16798ac8d9c91ea8d5e7911305d8c671',1,'ApresentarMatrizListaNef(Ant *lista, int linhas, int colunas, Nef *listaNef):&#160;funcao.c'],['../group___nefastos.html#ga16798ac8d9c91ea8d5e7911305d8c671',1,'ApresentarMatrizListaNef(Ant *lista, int linhas, int colunas, Nef *listaNef):&#160;funcao.c']]]
];
