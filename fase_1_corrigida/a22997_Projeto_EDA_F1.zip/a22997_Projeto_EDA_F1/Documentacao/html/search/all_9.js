var searchData=
[
  ['proxantena_0',['proxAntena',['../struct_ant.html#ae4906fba945c9bbb471249069b84bed8',1,'Ant']]],
  ['proxnef_1',['proxNef',['../struct_nef.html#ac7bc194eec4867eccf5ecf84c58c5eeb',1,'Nef']]]
];
