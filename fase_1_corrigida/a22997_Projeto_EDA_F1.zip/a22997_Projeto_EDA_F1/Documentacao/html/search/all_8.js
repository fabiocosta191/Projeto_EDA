var searchData=
[
  ['nef_0',['Nef',['../struct_nef.html',1,'']]],
  ['nefastos_1',['Fun��es de Manipula��o de Nefastos',['../group___nefastos.html',1,'']]]
];
