var struct_ant =
[
    [ "freqAntena", "struct_ant.html#a3419940d73191a069f0f2cb626622b92", null ],
    [ "id", "struct_ant.html#a7441ef0865bcb3db9b8064dd7375c1ea", null ],
    [ "proxAntena", "struct_ant.html#ae4906fba945c9bbb471249069b84bed8", null ],
    [ "x", "struct_ant.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "struct_ant.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];