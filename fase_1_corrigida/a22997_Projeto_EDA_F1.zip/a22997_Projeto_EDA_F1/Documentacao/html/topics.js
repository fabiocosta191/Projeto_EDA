var topics =
[
    [ "Fun��es de Manipula��o de Antenas", "group___antenas.html", "group___antenas" ],
    [ "Fun��es de Manipula��o de Nefastos", "group___nefastos.html", "group___nefastos" ],
    [ "Fun��es de Gest�o de Mem�ria", "group___memoria.html", "group___memoria" ]
];