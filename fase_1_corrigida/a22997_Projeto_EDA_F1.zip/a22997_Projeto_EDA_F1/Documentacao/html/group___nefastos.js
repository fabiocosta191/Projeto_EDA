var group___nefastos =
[
    [ "ApresentarListaNef", "group___nefastos.html#gaa28d290058a7ad68746554223e82fbe1", null ],
    [ "ApresentarMatrizListaNef", "group___nefastos.html#ga16798ac8d9c91ea8d5e7911305d8c671", null ],
    [ "EncontrarNefastos", "group___nefastos.html#ga2e4798a06d5d3c5469e10537a1a17121", null ],
    [ "InserirNefasto", "group___nefastos.html#gabcb2df429138321bf1a982da105b7eba", null ]
];