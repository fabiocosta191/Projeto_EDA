var struct_nef =
[
    [ "antena1", "struct_nef.html#a6fd3fc1721340aa6cda6ff64130ee22d", null ],
    [ "antena2", "struct_nef.html#a8480896859f1fd5c82e65d9409a60251", null ],
    [ "proxNef", "struct_nef.html#ac7bc194eec4867eccf5ecf84c58c5eeb", null ],
    [ "x", "struct_nef.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "struct_nef.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];