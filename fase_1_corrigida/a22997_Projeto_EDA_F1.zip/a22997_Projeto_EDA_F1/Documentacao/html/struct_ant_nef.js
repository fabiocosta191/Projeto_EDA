var struct_ant_nef =
[
    [ "lista", "struct_ant_nef.html#acc6bf784e10d704a24d429dce10c66fd", null ],
    [ "listaNef", "struct_ant_nef.html#a80c508e64ee6ab650bce0c1fceee5587", null ]
];