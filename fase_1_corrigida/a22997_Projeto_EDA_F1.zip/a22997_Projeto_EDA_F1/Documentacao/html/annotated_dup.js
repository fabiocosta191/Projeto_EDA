var annotated_dup =
[
    [ "Ant", "struct_ant.html", "struct_ant" ],
    [ "AntNef", "struct_ant_nef.html", "struct_ant_nef" ],
    [ "Nef", "struct_nef.html", "struct_nef" ]
];