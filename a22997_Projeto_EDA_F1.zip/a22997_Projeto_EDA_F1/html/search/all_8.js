var searchData=
[
  ['x_0',['x',['../struct_a_n_t.html#a6150e0515f7202e2fb518f7206ed97dc',1,'ANT::x'],['../struct_n_e_f.html#a6150e0515f7202e2fb518f7206ed97dc',1,'NEF::x']]]
];
