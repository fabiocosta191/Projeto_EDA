var struct_a_n_t =
[
    [ "freqAntena", "struct_a_n_t.html#a3419940d73191a069f0f2cb626622b92", null ],
    [ "proxAntena", "struct_a_n_t.html#aa5fc87ffe6a13c79d8daba3b55b34c0e", null ],
    [ "x", "struct_a_n_t.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "struct_a_n_t.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];