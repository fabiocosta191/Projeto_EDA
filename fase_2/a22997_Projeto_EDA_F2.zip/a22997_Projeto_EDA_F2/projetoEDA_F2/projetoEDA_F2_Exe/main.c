/**
 * @file main.c
 * @brief Ponto de entrada principal do programa que manipula grafos de antenas.
 *
 * Este ficheiro cont�m o `main`, respons�vel por:
 * - Carregar as antenas a partir de um ficheiro;
 * - Imprimir a matriz de antenas e zonas nefastas;
 * - Listar todas as arestas e as zonas nefastas associadas;
 * - Realizar travessias DFS e BFS a partir de uma antena escolhida;
 * - Encontrar todos os caminhos entre duas antenas;
 * - Libertar a mem�ria alocada dinamicamente no final.
 *
 * @author F�bio Rafael Gomes Costa
 * @date 18/05/2025
 */

#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

 /**
  * @brief Fun��o principal do programa.
  *
  * Executa uma sequ�ncia de opera��es sobre um grafo de antenas, carregado a partir de um ficheiro.
  * As opera��es incluem impress�o da matriz, listagem de arestas, execu��o de DFS, BFS e descoberta
  * de todos os caminhos entre dois n�s. Ao final, toda a mem�ria alocada � libertada.
  *
  * @return int Retorna 0 se a execu��o for bem-sucedida, ou 1 em caso de erro.
  */
int main() {
    Grafo grafo;
    Ant* listaAntenas = NULL;
    int linhas = 0, colunas = 0;
    int validacaoResultado = 0;

    // Leitura da matriz do ficheiro "antenas.txt"
    listaAntenas = LerLista("antenas", ".txt", &linhas, &colunas, &grafo);
    if (listaAntenas == NULL) {
        perror("Erro ao carregar a lista de antenas.\n");
        return 1;
    }

    // Imprime a matriz com antenas e zonas nefastas
    validacaoResultado = ImprimirMatriz(&grafo, linhas, colunas);
    if (validacaoResultado != 200) {
        perror("Erro ao imprimir a matriz.\n");
    }

    // Lista as arestas e zonas nefastas
    validacaoResultado = ListarArestasENefastos(&grafo, linhas, colunas);
    if (validacaoResultado != 200) {
        perror("Erro ao imprimir lista.\n");
    }

    // Executa a procura em profundidade (DFS) a partir da antena 3
    validacaoResultado = IniciarDFS(&grafo, 3);
    if (validacaoResultado != 200) {
        perror("Erro na procura em profundidade.\n");
    }

    // Executa a procura em largura (BFS) a partir da antena 3
    validacaoResultado = BFS(&grafo, 3);
    if (validacaoResultado != 200) {
        perror("Erro na procura em largura.\n");
    }

    // Encontra todos os caminhos poss�veis entre a antena 1 e 6
    validacaoResultado = TodosCaminhos(&grafo, 1, 6);
    if (validacaoResultado != 200) {
        perror("Erro na procura ao encontrar o caminho.\n");
    }

    // Liberta toda a mem�ria alocada
    validacaoResultado = FreeListaAntenas(listaAntenas, &grafo);
    if (validacaoResultado != 200) {
        perror("Erro ao libertar memoria.\n");
    }
    else {
        printf("Memoria libertada com sucesso.\n");
    }

    return 0;
}
